var timerIntervalId = null;

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    chrome.storage.local.remove('bgLifeTime');
    chrome.storage.local.set({
        bgLifeTime: new Date().getTime()
    });
    
    if (request.stop) {
        window.location.reload();
        return;
    }

    if (request.lifespan) return;
    
    if (request.history === 'tick') {
        historyTick();
    } else {
        console.log(`chrome.storage.local.get('isBlocking`);
        chrome.storage.local.get('isBlocking', (blocking) => {
            if (!blocking.isBlocking) {
                if (document.body.innerHTML === 'Blocked by Asana blocker') {
                    window.location.reload();
                } 
            }
            console.log(`Content script loaded....`);
            chrome.storage.local.get('blockedWebsites', (storage) => {
                const elem = document.createElement('div');
                elem.innerHTML = 'Blocked by Asana blocker';
                console.log(`blockedWebsites`, storage.blockedWebsites);
                if (storage.blockedWebsites && storage.blockedWebsites.length) {
                    if (storage.blockedWebsites.find(website => {
                        const condition = request.tab.url.includes(website.name)
                        || website.name === '*';
                        return condition;
                    })) {
                        console.log(`storage.blockedWebsites.find`);
                        chrome.storage.local.get('exceptionWebsites', (exStorage) => {
                            console.log(`exceptionWebsites `, exStorage);
                            if (exStorage.exceptionWebsites && 
                                Object.values(exStorage.exceptionWebsites).find(w => request.tab.url.includes(w.name))) {
                                console.log(`exStorage.exceptionWebsites.find`);
                                if (document.body.innerHTML === elem.innerHTML) {
                                    window.location.reload();
                                }
                                return;
                            } else if (!request.unblockWebsite) {
                                console.log(`else if (!request.unblockWebsite) {`);
                                document.body.innerHTML = elem.innerHTML;
                                stopTimer();
                            } else {
                                console.log(`else`);
                                if (document.body.innerHTML === elem.innerHTML) {
                                    window.location.reload();
                                }
                                startTimerInterval();
                            }
                        });
                    }
                } else {
                    sendResponse(true);
                }
            });
        });
    }
});

function historyTick() {
    chrome.storage.local.get('history', (storage) => {
        if (storage.history) {
            const history = storage.history;
            if (history.length > 500) {
                history.pop();
            }

            let currentDate = new Date();
            let date = '';
            date += `0${currentDate.getMonth()+1}`.slice(-2);
            date += `/` + `0${currentDate.getDate()}`.slice(-2);
            date += `/${currentDate.getFullYear()}`;
            date += ` ${currentDate.toLocaleTimeString().replace(/([\d]+:[\d]{2})(:[\d]{2})(.*)/, "$1$3").slice(0, 5)}`

            history.unshift({
                action: 'Task tick',
                description: 'Asana Task Ticked',
                date
            });

            chrome.storage.local.set({
                history
            });
        }
    });
}

function startTimerInterval() {
    timerIntervalId = setInterval(() => {
        setTimerToThepage();
    }, 333);
}

function stopTimer() {
    clearInterval(timerIntervalId);
    timerIntervalId = null;
}

function setTimerToThepage() {
    chrome.storage.local.get('timeleft', (tStorage) => {
        if (tStorage && tStorage.timeleft && tStorage.timeleft > -1) {
            let timer = document.getElementById('motivation-extension-timer');
            
            if (!timer) {
                timer = document.createElement('div');
                timer.setAttribute('id', 'motivation-extension-timer');
                timer.style.position = 'absolute';
                timer.style.backgroundColor = 'rgba(0, 128, 255, 0.8)';
                timer.style.padding = '5px';
                timer.style.top = '0';
                timer.style.right = '0';
                timer.style.zIndex = '99999';
                document.body.appendChild(timer);
            }
    
            timer.innerHTML = formatTime(tStorage.timeleft);
        } else {
            const timer = document.getElementById('motivation-extension-timer');
            if (timer) {
                timer.remove();
            }
            stopTimer();
        }
    });
}

function formatTime(seconds) {
    if (!seconds || seconds === -1) {
      return '00';
    }

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
  
    const formattedHours = hours.toString().padStart(2, '0');
    const formattedMinutes = minutes.toString().padStart(2, '0');
    const formattedSeconds = remainingSeconds.toString().padStart(2, '0');
    

    return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
}